/*
 * Versão de Homologação/Testes
 */
package br.gov.serpro.rtc.api.model.output.dadosabertos;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import br.gov.serpro.rtc.api.model.SerializationVisibility;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * Saída da API de dados abertos que expõe informações cadastrais de municípios
 * brasileiros. Retorna código e nome do município para consultas de localização
 * e validação geográfica usadas nas operações tributárias.
 */
@Getter
@Setter
@Builder
@JsonInclude(Include.NON_NULL)
public class MunicipioDadosAbertosOutput implements SerializationVisibility {

    @Schema(name = "codigo", description = "Código IBGE do Município", example = "4314902")
    private final Long codigo;

    @Schema(name = "nome", description = "Nome do município", example = "Porto Alegre")
    private final String nome;
}
