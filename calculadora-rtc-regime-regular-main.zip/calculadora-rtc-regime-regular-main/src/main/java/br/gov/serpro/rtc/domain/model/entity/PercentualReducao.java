/*
 * Versão de Homologação/Testes
 */
package br.gov.serpro.rtc.domain.model.entity;

import java.math.BigDecimal;
import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Entidade JPA da tabela {@code PERCENTUAL_REDUCAO} que armazena percentuais de
 * redução por classificação tributária e tributo, com vigência.
 */
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Data
@Entity
@Table(name = "PERCENTUAL_REDUCAO")
public class PercentualReducao {

    @EqualsAndHashCode.Include
    @Id
    @Column(name = "PERE_ID")
    private Long id;
    
    @ManyToOne
    @NotNull
    @JoinColumn(name = "PERE_CLTR_ID")
    private ClassificacaoTributaria classificacaoTributaria;
    
    @ManyToOne
    @NotNull
    @JoinColumn(name = "PERE_TBTO_ID")
    private Tributo tributo;

    @NotNull
    @Column(name = "PERE_VALOR")
    private BigDecimal valor;

    @NotNull
    @Column(name = "PERE_INICIO_VIGENCIA")
    private LocalDate inicioVigencia;

    @Column(name = "PERE_FIM_VIGENCIA")
    private LocalDate fimVigencia;

}
