/*
 * Versão de Homologação/Testes
 */
package br.gov.serpro.rtc.domain.service.exception;

import java.time.LocalDate;

/**
 * Exceção lançada para sinalizar alíquota referência não encontrada no domínio
 * de cálculo tributário.
 */
public class AliquotaReferenciaNaoEncontradaException extends EntidadeNaoEncontradaException {

    private static final long serialVersionUID = 202504161234567894L;

    private static final String DEFAULT_MESSAGE = "Alíquota de referência não encontrada";
    private static final String MESSAGE = "Alíquota de referência não encontrada para o tributo com id %s e data %s";

    public AliquotaReferenciaNaoEncontradaException() {
        super(DEFAULT_MESSAGE);
    }
    
    public AliquotaReferenciaNaoEncontradaException(Long idTributo, LocalDate data) {
        super(String.format(MESSAGE, idTributo, data));
    }
}
