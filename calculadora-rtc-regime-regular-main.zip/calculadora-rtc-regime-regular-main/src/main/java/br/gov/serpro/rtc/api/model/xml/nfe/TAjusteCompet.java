//
// Este arquivo foi gerado pela Eclipse Implementation of JAXB, v4.0.5 
// Consulte https://eclipse-ee4j.github.io/jaxb-ri 
// Todas as modificações neste arquivo serão perdidas após a recompilação do esquema de origem. 
//


package br.gov.serpro.rtc.api.model.xml.nfe;

import javax.xml.datatype.XMLGregorianCalendar;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlSchemaType;
import jakarta.xml.bind.annotation.XmlType;
import lombok.Getter;
import lombok.Setter;

/**
 * Tipo XML que representa o grupo de ajuste por competência de IBS/CBS do
 * documento fiscal Nota Fiscal Eletrônica (NFe), conforme o schema fiscal
 * correspondente.
 */
@Getter
@Setter
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TAjusteCompet", propOrder = {
    "competApur",
    "vIBS",
    "vCBS"
})
public class TAjusteCompet {

    @XmlElement(required = true)
    @XmlSchemaType(name = "gYearMonth")
    private XMLGregorianCalendar competApur;

    @XmlElement(required = true)
    private String vIBS;

    @XmlElement(required = true)
    private String vCBS;
}
